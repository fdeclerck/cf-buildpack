require 'dependencies'
require 'eol_deprecations'
require 'uri_translator'
